from setuptools import setup

setup(

	name="paquetecalculos",
	version="1.0",
	description="Paquete de redondeo y potencia",
	author="daniel",
	author_email="danielcaicedo@gmail.com",
	url="https://www.google.com/",
	packages=["calculos","calculos.redondeoPotencia"]


	)