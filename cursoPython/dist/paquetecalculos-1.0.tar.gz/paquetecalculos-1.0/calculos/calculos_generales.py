def sumar(op1,op2):
	print("El resultado de la suma es: ",op1+op2)

def restar(op1,op2):
	print("El resultado de la resta es: ",op1-op2)

def multiplicar(op1,op2):
	print("El resultado de la suma es: ",op1*op2)		

def dividir(dividendo,divisor):
	print("El resultado de la division es: ",dividendo/divisor)	

def potencia(base,exponente):
	print("El resultado de la potencia es: ",base**exponente)		

def redondear(numero):	
	print("El resultado de redondear es: ",round(numero))	